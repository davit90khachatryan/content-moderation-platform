import os
import json
import boto3
import traceback
from datetime import datetime

# Environment Variables
TABLE_NAME = os.getenv("TABLE_NAME")
if not TABLE_NAME:
    raise ValueError("Missing required environment variable: TABLE_NAME")

# AWS Clients
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

def handler(event, context):
    """Processes flagged comments from SQS and updates them in DynamoDB"""
    status_code = 200  # Assume success unless an error occurs
    errors = []

    print(f"✅ Lambda request ID: {context.aws_request_id}")
    print(f"✅ Received event: {json.dumps(event)}")  # ✅ Debugging

    for record in event.get("Records", []):
    try:
        message_body = json.loads(record["body"])
        comment_id = message_body.get("comment_id")

        # New manual review logic (set "APPROVED" or "REJECTED" instead of REVIEWED)
        table.update_item(
            Key={"comment_id": comment_id},
            UpdateExpression="SET review_status = :status, moderation_decision = :decision, reviewed_at = :timestamp",
            ExpressionAttributeValues={
                ":status": "PENDING_REVIEW",  # Default to pending until manually reviewed
                ":decision": None,  # No decision yet
                ":timestamp": datetime.utcnow().isoformat()
            }
        )


        # Delete message from SQS only after successful processing
        # sqs.delete_message(
        #     QueueUrl=SQS_QUEUE_URL,
        #     ReceiptHandle=record["receiptHandle"]
        # )

        print(f"✅ Successfully reviewed and deleted comment: {comment_id}")

    except Exception as e:
        print(f"❌ Error processing message: {e}")

    return {
        "statusCode": status_code,
        "body": json.dumps({
            "message": "Processing complete",
            "errors": errors if errors else None
        })
    }
